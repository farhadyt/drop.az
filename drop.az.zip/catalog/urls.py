# catalog/urls.py - ENHANCED VERSION WITH CATEGORY NAVIGATION
from django.urls import path, include
from django.views.generic import TemplateView
from . import views

# App namespace
app_name = 'catalog'

urlpatterns = [
    # =================================
    # MAIN PAGES
    # =================================
    
    # Ana səhifə (main home page with full layout)
    path('', views.home, name='home'),
    
    # =================================
    # CATEGORY PAGES
    # =================================
    
    # Bütün kateqoriyalar səhifəsi
    path('categories/', views.categories_view, name='categories'),
    path('kategoriyalar/', views.categories_view, name='categories_az'),
    
    # Spesifik kateqoriya səhifəsi (və onun məhsulları)
    path('categories/<slug:slug>/', views.category_detail, name='category_detail'),
    path('kategoriya/<slug:slug>/', views.category_detail, name='category_detail_az'),
    
    # Alt kateqoriya səhifəsi
    path('categories/<slug:parent_slug>/<slug:slug>/', views.subcategory_detail, name='subcategory_detail'),
    path('kategoriya/<slug:parent_slug>/<slug:slug>/', views.subcategory_detail, name='subcategory_detail_az'),
    
    # =================================
    # PRODUCT PAGES
    # =================================
    
    # Məhsul siyahısı
    path('products/', views.product_list, name='product_list'),
    path('mehsullar/', views.product_list, name='product_list_az'),

    # Hero versiyaları üçün
    path('products-hero/', views.product_list_hero, name='product_list_hero'),
    path('product-hero/<slug:slug>/', views.product_detail_hero, name='product_detail_hero'),
    
    # Məhsul təfsilatı
    path('product/<slug:slug>/', views.product_detail, name='product_detail'),
    path('mehsul/<slug:slug>/', views.product_detail, name='product_detail_az'),
    
    # Kateqoriyaya görə məhsullar
    path('products/category/<slug:category_slug>/', views.products_by_category, name='products_by_category'),
    path('mehsullar/kategoriya/<slug:category_slug>/', views.products_by_category, name='products_by_category_az'),
    
    # =================================
    # AJAX & API ENDPOINTS
    # =================================
    
    # Axtarış təklifləri (AJAX)
    path('api/search-suggestions/', views.search_suggestions, name='search_suggestions'),
    
    # Newsletter abunəliyi (AJAX)
    path('api/newsletter-subscribe/', views.newsletter_subscribe, name='newsletter_subscribe'),
    
    # Məhsul statistikaları (AJAX)
    path('api/product-stats/', views.get_product_stats, name='product_stats'),
    
    # Kateqoriya statistikaları (AJAX)
    path('api/category-stats/', views.get_category_stats, name='category_stats'),
    
    # Məhsul filtrləri (AJAX)
    path('api/filter-products/', views.ProductFilterView.as_view(), name='filter_products'),
    
    # Kateqoriya məhsulları (AJAX)
    path('api/category-products/<slug:category_slug>/', views.CategoryProductsView.as_view(), name='category_products'),
    
    # =================================
    # SPECIAL PAGES
    # =================================
    
    # Haqqımızda səhifəsi
    path('about/', TemplateView.as_view(
        template_name='pages/about.html',
        extra_context={
            'page_title': 'Haqqımızda',
            'meta_description': 'drop.az haqqında məlumat - missiyamız və dəyərlərimiz'
        }
    ), name='about'),
    
    # Əlaqə səhifəsi
    path('contact/', TemplateView.as_view(
        template_name='pages/contact.html',
        extra_context={
            'page_title': 'Əlaqə',
            'meta_description': 'drop.az ilə əlaqə saxlayın - telefon, e-mail və ünvan'
        }
    ), name='contact'),
    
    # Çatdırılma məlumatları
    path('delivery/', TemplateView.as_view(
        template_name='pages/delivery.html',
        extra_context={
            'page_title': 'Çatdırılma',
            'meta_description': 'drop.az çatdırılma şərtləri və qiymətləri'
        }
    ), name='delivery'),
    
    # Qaytarma şərtləri
    path('returns/', TemplateView.as_view(
        template_name='pages/returns.html',
        extra_context={
            'page_title': 'Qaytarma',
            'meta_description': 'drop.az qaytarma şərtləri və prosedurları'
        }
    ), name='returns'),
    
    # Ödəniş üsulları
    path('payment/', TemplateView.as_view(
        template_name='pages/payment.html',
        extra_context={
            'page_title': 'Ödəniş',
            'meta_description': 'drop.az ödəniş üsulları və təhlükəsizlik'
        }
    ), name='payment'),
    
    # FAQ - Tez-tez verilən suallar
    path('faq/', TemplateView.as_view(
        template_name='pages/faq.html',
        extra_context={
            'page_title': 'FAQ',
            'meta_description': 'drop.az tez-tez verilən suallar və cavablar'
        }
    ), name='faq'),
    
    # Zəmanət şərtləri
    path('warranty/', TemplateView.as_view(
        template_name='pages/warranty.html',
        extra_context={
            'page_title': 'Zəmanət',
            'meta_description': 'drop.az zəmanət şərtləri və xidmətləri'
        }
    ), name='warranty'),
    
    # =================================
    # LEGAL PAGES
    # =================================
    
    # İstifadə şərtləri
    path('terms/', TemplateView.as_view(
        template_name='legal/terms.html',
        extra_context={
            'page_title': 'İstifadə Şərtləri',
            'meta_description': 'drop.az istifadə şərtləri və qaydalar'
        }
    ), name='terms'),
    
    # Məxfilik siyasəti
    path('privacy/', TemplateView.as_view(
        template_name='legal/privacy.html',
        extra_context={
            'page_title': 'Məxfilik Siyasəti',
            'meta_description': 'drop.az məxfilik siyasəti və şəxsi məlumatların qorunması'
        }
    ), name='privacy'),
    
    # Çerez siyasəti
    path('cookies/', TemplateView.as_view(
        template_name='legal/cookies.html',
        extra_context={
            'page_title': 'Çerez Siyasəti',
            'meta_description': 'drop.az çerez siyasəti və istifadəsi'
        }
    ), name='cookies'),
    
    # =================================
    # SEARCH & FILTER URLS
    # =================================
    
    # Axtarış səhifəsi
    path('search/', views.product_list, name='search'),
    path('axtar/', views.product_list, name='search_az'),
    
    # Qiymət aralığı filter
    path('products/price/<int:min_price>-<int:max_price>/', views.product_list, name='products_by_price'),
    
    # Kateqoriya + qiymət filteri
    path('categories/<slug:category_slug>/price/<int:min_price>-<int:max_price>/', 
         views.products_by_category, name='category_products_by_price'),
    
    # =================================
    # SEO & UTILITY URLS
    # =================================
    
    # XML Sitemap
    path('sitemap.xml', views.sitemap_view, name='sitemap'),
    
    # Robots.txt
    path('robots.txt', TemplateView.as_view(
        template_name='robots.txt',
        content_type='text/plain'
    ), name='robots'),
    
    # =================================
    # LANGUAGE-SPECIFIC URLS
    # =================================
    
    # Azərbaycan dilində URL-lər
    path('ana-sehife/', views.home, name='home_az'),
    path('endirimler/', TemplateView.as_view(template_name='pages/sales.html'), name='sales_az'),
    path('yenilikler/', TemplateView.as_view(template_name='pages/new_products.html'), name='new_products_az'),
    
    # =================================
    # BREADCRUMB & NAVIGATION HELPERS
    # =================================
    
    # Kateqoriya yolu (breadcrumb helper)
    path('api/category-breadcrumb/<slug:category_slug>/', views.get_category_breadcrumb, name='category_breadcrumb'),
    
    # Kateqoriya ağacı (navigation helper)
    path('api/category-tree/', views.get_category_tree, name='category_tree'),
]

# =================================
# API VERSIONING
# =================================

# API v1 patterns
api_v1_patterns = [
    path('v1/products/', views.product_list, name='api_v1_products'),
    path('v1/categories/', views.categories_view, name='api_v1_categories'),
    path('v1/category/<slug:slug>/', views.category_detail, name='api_v1_category_detail'),
    path('v1/search/', views.search_suggestions, name='api_v1_search'),
]

# API patterns-i əlavə et
urlpatterns += [path('api/', include(api_v1_patterns))]

# =================================
# ERROR HANDLING URLS
# =================================

# Custom error pages (if needed)
handler404 = 'catalog.views.handler404'
handler500 = 'catalog.views.handler500'