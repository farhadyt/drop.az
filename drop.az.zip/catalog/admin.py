# catalog/admin.py
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.db.models import Count, Sum, Q
from django.http import HttpResponse
from django.shortcuts import redirect
from django.contrib import messages
from django.utils import timezone
import csv
import io
from PIL import Image
from django.core.files.base import ContentFile

from .models import Category, Product

# =================================
# ADMIN MIXINS VƏ UTILITY CLASSES
# =================================

class ExportCsvMixin:
    """
    CSV export funksionallığı üçün mixin
    """
    def export_as_csv(self, request, queryset):
        meta = self.model._meta
        field_names = [field.name for field in meta.fields]

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename={meta}.csv'
        writer = csv.writer(response)

        writer.writerow(field_names)
        for obj in queryset:
            row = writer.writerow([getattr(obj, field) for field in field_names])

        return response

    export_as_csv.short_description = "Seçilmiş məhsulları CSV olaraq ixrac et"

# =================================
# CATEGORY ADMIN
# =================================

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin, ExportCsvMixin):
    """
    Kateqoriya modelinin admin paneli konfiqurasiyası
    """
    list_display = [
        'name', 
        'slug', 
        'parent', 
        'product_count', 
        'get_subcategory_count',
        'created_date'
    ]
    list_filter = [
        'parent',
        ('parent', admin.EmptyFieldListFilter),  # Parent var/yox filter
    ]
    search_fields = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)}
    ordering = ['name']
    list_per_page = 20
    
    # Hierarchy üçün indentation
    list_display_links = ['name']
    
    # Readonly fields
    readonly_fields = ['get_product_list', 'get_category_stats']
    
    # Fieldsets - Admin panelində formun təşkili
    fieldsets = (
        ('Əsas Məlumatlar', {
            'fields': ('name', 'slug', 'parent')
        }),
        ('Statistikalar', {
            'fields': ('get_product_list', 'get_category_stats'),
            'classes': ('collapse',),
            'description': 'Bu kateqoriya haqqında statistik məlumatlar'
        }),
    )
    
    # Actions
    actions = ['export_as_csv', 'make_parent_category']

    def get_queryset(self, request):
        """
        QuerySet optimizasiyası - N+1 probleminin həlli
        """
        return super().get_queryset(request).select_related('parent').annotate(
            products_count=Count('products', filter=Q(products__available=True))
        )

    def product_count(self, obj):
        """
        Kateqoriyadakı məhsul sayını göstərir
        """
        count = obj.products_count if hasattr(obj, 'products_count') else obj.products.filter(available=True).count()
        if count > 0:
            url = reverse('admin:catalog_product_changelist') + f'?category__id__exact={obj.id}'
            return format_html('<a href="{}" style="color: #0066cc;">{} məhsul</a>', url, count)
        return format_html('<span style="color: #999;">0 məhsul</span>')
    product_count.short_description = 'Məhsul sayı'
    product_count.admin_order_field = 'products_count'

    def get_subcategory_count(self, obj):
        """
        Alt kateqoriya sayını göstərir
        """
        count = obj.children.count()
        if count > 0:
            return format_html('<span style="color: #28a745;">{} alt kateqoriya</span>', count)
        return format_html('<span style="color: #999;">Alt kateqoriya yox</span>')
    get_subcategory_count.short_description = 'Alt kateqoriyalar'

    def created_date(self, obj):
        """
        Yaradılma tarixini formatlayır
        """
        if hasattr(obj, 'created_at'):
            return obj.created_at.strftime('%d.%m.%Y')
        return '-'
    created_date.short_description = 'Yaradılma tarixi'

    def get_product_list(self, obj):
        """
        Kateqoriyadakı məhsulların siyahısını göstərir
        """
        products = obj.products.filter(available=True)[:5]
        if products:
            product_links = []
            for product in products:
                url = reverse('admin:catalog_product_change', args=[product.id])
                product_links.append(f'<a href="{url}" target="_blank">{product.name}</a>')
            
            result = '<br>'.join(product_links)
            if obj.products.filter(available=True).count() > 5:
                result += f'<br><em>... və daha {obj.products.filter(available=True).count() - 5} məhsul</em>'
            return mark_safe(result)
        return 'Bu kateqoriyada məhsul yoxdur'
    get_product_list.short_description = 'Məhsullar'

    def get_category_stats(self, obj):
        """
        Kateqoriya statistikalarını göstərir
        """
        stats = []
        
        # Ümumi məhsul sayı
        total_products = obj.products.count()
        available_products = obj.products.filter(available=True).count()
        stats.append(f'Ümumi məhsul: {total_products}')
        stats.append(f'Aktiv məhsul: {available_products}')
        
        # Stok məlumatları
        if available_products > 0:
            total_stock = obj.products.filter(available=True).aggregate(
                total=Sum('stock')
            )['total'] or 0
            low_stock = obj.products.filter(available=True, stock__lte=5).count()
            
            stats.append(f'Ümumi stok: {total_stock}')
            if low_stock > 0:
                stats.append(f'<span style="color: #dc3545;">Az stoklu: {low_stock}</span>')
        
        return mark_safe('<br>'.join(stats))
    get_category_stats.short_description = 'Statistikalar'

    def make_parent_category(self, request, queryset):
        """
        Seçilmiş kateqoriyaları ana kateqoriya edir
        """
        updated = queryset.update(parent=None)
        self.message_user(
            request,
            f'{updated} kateqoriya ana kateqoriya edildi.',
            messages.SUCCESS
        )
    make_parent_category.short_description = "Ana kateqoriya et"

# =================================
# PRODUCT ADMIN
# =================================

class ProductImageInline(admin.TabularInline):
    """
    Məhsul şəkilləri üçün inline admin (gələcək üçün)
    """
    # model = ProductImage  # Bu model yaradılmalıdır
    extra = 1
    max_num = 5

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin, ExportCsvMixin):
    """
    Məhsul modelinin admin paneli konfiqurasiyası
    """
    list_display = [
        'get_image_thumbnail',
        'name',
        'category',
        'get_formatted_price',
        'stock',
        'get_stock_status',
        'available',
        'get_created_date',
        'get_admin_actions'
    ]
    
    list_filter = [
        'available',
        'category',
        'created_at',
        ('stock', admin.SimpleListFilter),  # Custom stock filter
        StockLevelFilter,  # Custom filter class
    ]
    
    search_fields = [
        'name', 
        'description', 
        'category__name',
        'slug'
    ]
    
    list_editable = [
        'price', 
        'stock', 
        'available'
    ]
    
    prepopulated_fields = {'slug': ('name',)}
    
    ordering = ['-created_at']
    list_per_page = 25
    
    # Date hierarchy
    date_hierarchy = 'created_at'
    
    # Readonly fields
    readonly_fields = [
        'get_image_preview',
        'created_at',
        'updated_at',
        'get_product_stats',
        'get_seo_preview'
    ]
    
    # Fieldsets
    fieldsets = (
        ('Əsas Məlumatlar', {
            'fields': ('name', 'slug', 'category', 'description')
        }),
        ('Qiymət və Stok', {
            'fields': ('price', 'stock', 'available'),
            'classes': ('wide',)
        }),
        ('Şəkil', {
            'fields': ('image', 'get_image_preview'),
            'classes': ('collapse',)
        }),
        ('SEO və Optimallaşdırma', {
            'fields': ('get_seo_preview',),
            'classes': ('collapse',),
            'description': 'Axtarış mühərrikləri üçün optimallaşdırma məlumatları'
        }),
        ('Sistem Məlumatları', {
            'fields': ('created_at', 'updated_at', 'get_product_stats'),
            'classes': ('collapse',)
        }),
    )
    
    # Filter horizontal (Many-to-Many fields üçün)
    # filter_horizontal = ['tags']  # Gələcəkdə tag sistemi üçün
    
    # Actions
    actions = [
        'export_as_csv',
        'make_available',
        'make_unavailable',
        'set_low_stock_alert',
        'duplicate_products'
    ]
    
    # Inlines (əlaqəli modellər)
    # inlines = [ProductImageInline]

    def get_queryset(self, request):
        """
        QuerySet optimizasiyası
        """
        return super().get_queryset(request).select_related('category')

    def get_image_thumbnail(self, obj):
        """
        Məhsul şəklinin kiçik versiyasını göstərir
        """
        if obj.image:
            return format_html(
                '<img src="{}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;" />',
                obj.image.url
            )
        return format_html(
            '<div style="width: 50px; height: 50px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border-radius: 4px; color: #999; font-size: 12px;">Şəkil yox</div>'
        )
    get_image_thumbnail.short_description = 'Şəkil'

    def get_image_preview(self, obj):
        """
        Məhsul şəklinin böyük preview-ını göstərir
        """
        if obj.image:
            return format_html(
                '<img src="{}" style="max-width: 300px; max-height: 300px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);" />',
                obj.image.url
            )
        return 'Şəkil yüklənməyib'
    get_image_preview.short_description = 'Şəkil Preview'

    def get_formatted_price(self, obj):
        """
        Qiyməti formatlanmış şəkildə göstərir
        """
        return format_html(
            '<span style="color: #28a745; font-weight: bold;">{:.2f} AZN</span>',
            obj.price
        )
    get_formatted_price.short_description = 'Qiymət'
    get_formatted_price.admin_order_field = 'price'

    def get_stock_status(self, obj):
        """
        Stok statusunu rənglərlə göstərir
        """
        if obj.stock == 0:
            return format_html(
                '<span style="color: #dc3545; font-weight: bold;">Stok bitib</span>'
            )
        elif obj.stock <= 5:
            return format_html(
                '<span style="color: #ffc107; font-weight: bold;">Az qalıb ({} ədəd)</span>',
                obj.stock
            )
        else:
            return format_html(
                '<span style="color: #28a745; font-weight: bold;">Kifayət qədər ({} ədəd)</span>',
                obj.stock
            )
    get_stock_status.short_description = 'Stok Status'

    def get_created_date(self, obj):
        """
        Yaradılma tarixini formatlanmış şəkildə göstərir
        """
        return obj.created_at.strftime('%d.%m.%Y %H:%M')
    get_created_date.short_description = 'Yaradılma tarixi'
    get_created_date.admin_order_field = 'created_at'

    def get_admin_actions(self, obj):
        """
        Hər məhsul üçün fərdi əməliyyat düymələri
        """
        actions = []
        
        # View on site
        actions.append(
            f'<a href="/product/{obj.slug}/" target="_blank" style="color: #007cba; text-decoration: none;" title="Saytda bax">👁️</a>'
        )
        
        # Duplicate
        duplicate_url = reverse('admin:catalog_product_add') + f'?duplicate={obj.id}'
        actions.append(
            f'<a href="{duplicate_url}" style="color: #007cba; text-decoration: none;" title="Kopyala">📋</a>'
        )
        
        # Stock alert
        if obj.stock <= 5:
            actions.append('<span style="color: #ffc107;" title="Az stok">⚠️</span>')
        
        return format_html(' '.join(actions))
    get_admin_actions.short_description = 'Əməliyyatlar'

    def get_product_stats(self, obj):
        """
        Məhsul statistikalarını göstərir
        """
        stats = []
        
        # Ümumi məlumatlar
        stats.append(f'Slug: {obj.slug}')
        stats.append(f'ID: {obj.id}')
        
        # Stok məlumatları
        if obj.stock > 0:
            stock_value = obj.stock * obj.price
            stats.append(f'Stok dəyəri: {stock_value:.2f} AZN')
        
        # Tarix məlumatları
        stats.append(f'Yaradılıb: {obj.created_at.strftime("%d.%m.%Y %H:%M")}')
        if obj.updated_at != obj.created_at:
            stats.append(f'Yenilənib: {obj.updated_at.strftime("%d.%m.%Y %H:%M")}')
        
        return mark_safe('<br>'.join(stats))
    get_product_stats.short_description = 'Məhsul Statistikaları'

    def get_seo_preview(self, obj):
        """
        SEO preview göstərir
        """
        preview = []
        
        # Title preview
        title = f"{obj.name} - drop.az"
        preview.append(f'<strong>Title:</strong> {title}')
        
        # Description preview
        description = obj.description[:160] if obj.description else f"{obj.name} məhsulu drop.az platformasında"
        preview.append(f'<strong>Description:</strong> {description}...')
        
        # URL preview
        url = f"https://drop.az/product/{obj.slug}/"
        preview.append(f'<strong>URL:</strong> <a href="{url}" target="_blank">{url}</a>')
        
        return mark_safe('<br><br>'.join(preview))
    get_seo_preview.short_description = 'SEO Preview'

    # Custom Actions
    def make_available(self, request, queryset):
        updated = queryset.update(available=True)
        self.message_user(
            request,
            f'{updated} məhsul aktiv edildi.',
            messages.SUCCESS
        )
    make_available.short_description = "Seçilmiş məhsulları aktiv et"

    def make_unavailable(self, request, queryset):
        updated = queryset.update(available=False)
        self.message_user(
            request,
            f'{updated} məhsul deaktiv edildi.',
            messages.WARNING
        )
    make_unavailable.short_description = "Seçilmiş məhsulları deaktiv et"

    def set_low_stock_alert(self, request, queryset):
        low_stock_products = queryset.filter(stock__lte=5, available=True)
        count = low_stock_products.count()
        
        if count > 0:
            # Burada e-mail göndərmə funksionallığı əlavə edilə bilər
            self.message_user(
                request,
                f'{count} məhsulda az stok xəbərdarlığı aktivləşdirildi.',
                messages.WARNING
            )
        else:
            self.message_user(
                request,
                'Seçilmiş məhsullarda az stok problemi yoxdur.',
                messages.INFO
            )
    set_low_stock_alert.short_description = "Az stok xəbərdarlığı göndər"

    def duplicate_products(self, request, queryset):
        """
        Məhsulları kopyalayır
        """
        duplicated = 0
        for product in queryset:
            product.pk = None
            product.name = f"{product.name} (kopya)"
            product.slug = f"{product.slug}-kopya-{timezone.now().strftime('%Y%m%d')}"
            product.save()
            duplicated += 1
        
        self.message_user(
            request,
            f'{duplicated} məhsul kopyalandı.',
            messages.SUCCESS
        )
    duplicate_products.short_description = "Seçilmiş məhsulları kopyala"

# =================================
# CUSTOM FILTERS
# =================================

class StockLevelFilter(admin.SimpleListFilter):
    """
    Stok səviyyəsinə görə filter
    """
    title = 'Stok səviyyəsi'
    parameter_name = 'stock_level'

    def lookups(self, request, model_admin):
        return (
            ('in_stock', 'Stokda var (>5)'),
            ('low_stock', 'Az stok (1-5)'),
            ('out_of_stock', 'Stok yoxdur (0)'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'in_stock':
            return queryset.filter(stock__gt=5)
        if self.value() == 'low_stock':
            return queryset.filter(stock__range=(1, 5))
        if self.value() == 'out_of_stock':
            return queryset.filter(stock=0)

# =================================
# ADMIN SITE CUSTOMIZATION
# =================================

# Admin panel başlığı və metadata
admin.site.site_header = 'drop.az İdarəetmə Paneli'
admin.site.site_title = 'drop.az Admin'
admin.site.index_title = 'İdarəetmə Paneli'

# Custom admin actions
def export_selected_as_csv(modeladmin, request, queryset):
    """
    Global CSV export action
    """
    meta = queryset.model._meta
    field_names = [field.name for field in meta.fields]

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename={meta}.csv'
    writer = csv.writer(response)

    writer.writerow(field_names)
    for obj in queryset:
        writer.writerow([getattr(obj, field) for field in field_names])

    return response

export_selected_as_csv.short_description = "CSV olaraq ixrac et"

# Global action əlavə et
admin.site.add_action(export_selected_as_csv)

# =================================
# ADMIN DASHBOARD CUSTOMIZATION
# =================================

# Bu hissə dashboard üçün custom widget-lər əlavə etmək üçün istifadə olunur
# Məsələn: statistik chart-lar, son əməliyyatlar və s.

"""
Admin Panel Xüsusiyyətləri:

1. ✅ Optimized querysets (N+1 problem həlli)
2. ✅ Custom list displays (thumbnail, status indicators)
3. ✅ Advanced filtering (stock levels, categories)
4. ✅ Bulk actions (export, activate/deactivate)
5. ✅ SEO preview
6. ✅ Product statistics
7. ✅ Image thumbnails
8. ✅ Custom fieldsets
9. ✅ Date hierarchy
10. ✅ Search functionality

Gələcək üçün əlavə edilə bilər:
- Bulk import/export functionality
- Image optimization
- Advanced reporting
- Inventory management
- Sales analytics
"""